// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (C) 2026 Hamza Ghandouri <hamza.ghandouri@gmail.com> - https://miqraa.org

import { useTranslation } from "react-i18next";
import { cn } from "@/lib/utils";
import type { HalaqahType } from "../../types";

export type FilterRiwaya = "hafs" | "warsh" | "qalun";
export type ActiveFilter = "all" | "active" | "inactive";

const chipBase =
  "rounded-xl px-4 py-2 text-sm font-medium transition";
const chipActive = "bg-[var(--color-primary)] text-white";
const chipIdle = "bg-gray-100 text-[var(--color-text-muted)] hover:bg-gray-200";

export interface RoomFiltersProps {
  halaqahType: HalaqahType | "";
  riwaya: FilterRiwaya | "";
  activeFilter: ActiveFilter;
  onHalaqahTypeChange: (v: HalaqahType | "") => void;
  onRiwayaChange: (v: FilterRiwaya | "") => void;
  onActiveFilterChange: (v: ActiveFilter) => void;
}

export function RoomFilters({
  halaqahType,
  riwaya,
  activeFilter,
  onHalaqahTypeChange,
  onRiwayaChange,
  onActiveFilterChange,
}: RoomFiltersProps) {
  const { t } = useTranslation();

  const halaqahOptions: { value: HalaqahType | ""; labelKey: string }[] = [
    { value: "", labelKey: "common.all" },
    { value: "hifz", labelKey: "rooms.halaqahHifz" },
    { value: "tilawa", labelKey: "rooms.halaqahTilawa" },
    { value: "muraja", labelKey: "rooms.halaqahMuraja" },
    { value: "tajweed", labelKey: "rooms.halaqahTajweed" },
  ];

  const riwayaOptions: { value: FilterRiwaya | ""; labelKey: string }[] = [
    { value: "", labelKey: "common.all" },
    { value: "hafs", labelKey: "mushaf.hafs" },
    { value: "warsh", labelKey: "mushaf.warsh" },
    { value: "qalun", labelKey: "mushaf.qalun" },
  ];

  const statusOptions: { value: ActiveFilter; labelKey: string }[] = [
    { value: "all", labelKey: "common.all" },
    { value: "active", labelKey: "common.active" },
    { value: "inactive", labelKey: "common.inactive" },
  ];

  return (
    <div className="flex flex-col gap-4">
      <div>
        <p className="mb-2 text-sm font-medium text-[var(--color-text)]">{t("rooms.filterByStatus")}</p>
        <div className="flex flex-wrap gap-2">
          {statusOptions.map(({ value, labelKey }) => (
            <button
              key={value}
              type="button"
              onClick={() => onActiveFilterChange(value)}
              className={cn(chipBase, activeFilter === value ? chipActive : chipIdle)}
            >
              {t(labelKey)}
            </button>
          ))}
        </div>
      </div>

      <div>
        <p className="mb-2 text-sm font-medium text-[var(--color-text)]">{t("rooms.filterByHalaqahType")}</p>
        <div className="flex flex-wrap gap-2">
          {halaqahOptions.map(({ value, labelKey }) => (
            <button
              key={value || "all-h"}
              type="button"
              onClick={() => onHalaqahTypeChange(value)}
              className={cn(chipBase, halaqahType === value ? chipActive : chipIdle)}
            >
              {t(labelKey)}
            </button>
          ))}
        </div>
      </div>

      <div>
        <p className="mb-2 text-sm font-medium text-[var(--color-text)]">{t("rooms.filterByRiwaya")}</p>
        <div className="flex flex-wrap gap-2">
          {riwayaOptions.map(({ value, labelKey }) => (
            <button
              key={value || "all-r"}
              type="button"
              onClick={() => onRiwayaChange(value)}
              className={cn(chipBase, riwaya === value ? chipActive : chipIdle)}
            >
              {t(labelKey)}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
