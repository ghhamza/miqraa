// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (C) 2026 Hamza Ghandouri <hamza.ghandouri@gmail.com> - https://miqraa.org

import { useEffect, useMemo, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { Link, useNavigate, useParams } from "react-router-dom";
import { Archive, Pencil, RotateCcw } from "lucide-react";
import { useTranslation } from "react-i18next";
import type { Enrollment, Room } from "../../types";
import { useAuthStore } from "../../stores/authStore";
import { Button } from "../../components/ui/Button";
import {
  AlertDialog,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "../../components/ui/alert-dialog";
import { RoomFormModal } from "../../components/rooms/RoomFormModal";
import { ArchiveRoomModal } from "../../components/rooms/ArchiveRoomModal";
import { EnrollStudentModal } from "../../components/enrollment/EnrollStudentModal";
import { RemoveStudentModal } from "../../components/enrollment/RemoveStudentModal";
import { SessionFormModal } from "../../components/sessions/SessionFormModal";
import { RecitationFormModal } from "../../components/recitations/RecitationFormModal";
import { PageShell } from "../../components/layout/PageShell";
import { halaqahBadgeClass } from "../../lib/halaqahUi";
import { riwayaBadgeClass } from "../../lib/riwayaUi";
import {
  calendarGridEnd,
  calendarGridStart,
  endOfMonth,
  startOfMonth,
} from "../../lib/calendarUtils";
import { GettingStartedBanner } from "../../components/room/GettingStartedBanner";
import { roomKeys } from "../../lib/queryKeys";
import { RoomOverviewSection } from "./sections/RoomOverviewSection";
import { RoomStudentsSection } from "./sections/RoomStudentsSection";
import { RoomSessionsSection, type RoomSessionsViewMode } from "./sections/RoomSessionsSection";
import { RoomRecitationsSection } from "./sections/RoomRecitationsSection";
import {
  useJoinRoom,
  useInvalidateRoomRecitations,
  useInvalidateRoomSessions,
  useRoom,
  useRoomEnrollments,
  useRoomRecentRecitations,
  useUnarchiveRoom,
  useWithdrawRoom,
} from "../../data/rooms";
import { useCalendarSessions } from "../../data/sessions";

function canManage(user: { id: string; role: string } | null, room: Room): boolean {
  if (!user) return false;
  if (user.role === "admin") return true;
  return user.role === "teacher" && user.id === room.teacher_id;
}

function capitalize(s: string): string {
  return s.charAt(0).toUpperCase() + s.slice(1);
}

export function RoomDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { t } = useTranslation();
  const user = useAuthStore((s) => s.user);
  const isAdmin = user?.role === "admin";

  const [formOpen, setFormOpen] = useState(false);
  const [archiveOpen, setArchiveOpen] = useState(false);
  const [enrollOpen, setEnrollOpen] = useState(false);
  const [removeEnrollment, setRemoveEnrollment] = useState<Enrollment | null>(null);
  const [sessionsViewMode, setSessionsViewMode] = useState<RoomSessionsViewMode>("calendar");
  const [calendarCursor, setCalendarCursor] = useState(() => new Date());
  const [listMonthCursor, setListMonthCursor] = useState(() => {
    const d = new Date();
    return new Date(d.getFullYear(), d.getMonth(), 1, 0, 0, 0, 0);
  });
  const [sessionFormOpen, setSessionFormOpen] = useState(false);
  const [sessionPrefillDate, setSessionPrefillDate] = useState<Date | null>(null);
  const [sessionPresetMorning, setSessionPresetMorning] = useState(false);
  const [recitationFormOpen, setRecitationFormOpen] = useState(false);
  const [studentConfirm, setStudentConfirm] = useState<"leave" | "cancel" | null>(null);
  const invalidateRoomSessions = useInvalidateRoomSessions(id ?? "");
  const invalidateRoomRecitations = useInvalidateRoomRecitations(id ?? "");

  const roomQuery = useRoom(id);

  const room = roomQuery.data ?? null;
  const forbidden =
    (roomQuery.error as { response?: { status?: number } } | null)?.response?.status === 403;
  const canManageRoom = !!room && !!user && canManage(user, room);

  const enrollmentsQuery = useRoomEnrollments(id, canManageRoom);

  const enrollments = enrollmentsQuery.data ?? [];

  const sessionsRange = useMemo(() => {
    if (sessionsViewMode === "calendar") {
      return {
        from: calendarGridStart(calendarCursor).toISOString(),
        to: calendarGridEnd(calendarCursor).toISOString(),
      };
    }
    return {
      from: startOfMonth(listMonthCursor).toISOString(),
      to: endOfMonth(listMonthCursor).toISOString(),
    };
  }, [sessionsViewMode, calendarCursor, listMonthCursor]);

  const sessionsQuery = useCalendarSessions(
    sessionsRange.from,
    sessionsRange.to,
    id ?? "",
    !!id && !!room,
  );

  useEffect(() => {
    if (!id || !room) return;
    void invalidateRoomSessions();
  }, [id, room, sessionsRange.from, sessionsRange.to, invalidateRoomSessions]);

  const sessions = useMemo(() => {
    const items = sessionsQuery.data ?? [];
    if (sessionsViewMode === "list") {
      return [...items].sort((a, b) => new Date(a.scheduled_at).getTime() - new Date(b.scheduled_at).getTime());
    }
    return items;
  }, [sessionsQuery.data, sessionsViewMode]);
  const sessionsLoading = sessionsQuery.isFetching;

  const recitationsQuery = useRoomRecentRecitations(id, !!room);

  const roomRecitations = recitationsQuery.data ?? [];
  const recitationsLoading = recitationsQuery.isPending;
  const loading = roomQuery.isPending;

  const restoreMutation = useUnarchiveRoom();

  const joinMutation = useJoinRoom(undefined, (message) => window.alert(message));

  const withdrawMutation = useWithdrawRoom(id ?? "", () => setStudentConfirm(null), (message) => window.alert(message));

  const restoreLoading = restoreMutation.isPending;
  const studentActionLoading = joinMutation.isPending || withdrawMutation.isPending;

  function handleRestore() {
    if (!room || restoreLoading) return;
    restoreMutation.mutate(room.id);
  }

  function handleStudentJoin() {
    if (!room || !id || studentActionLoading) return;
    joinMutation.mutate(room.id);
  }

  function confirmStudentWithdrawal() {
    if (!room || !id || studentActionLoading) return;
    withdrawMutation.mutate();
  }

  const showActions = room ? canManage(user, room) : false;
  const enrolledCount = room?.enrolled_count ?? 0;
  const isArchived = room ? !room.is_active : false;
  const isRoomTeacher = user?.role === "teacher" && !!room && user.id === room.teacher_id;

  const showStudentsSection =
    showActions || (user?.role === "student" && room?.my_status === "approved");
  const showRecitationsSection =
    showActions || (user?.role === "student" && room?.my_status === "approved");

  if (loading) {
    return (
      <div className="flex justify-center py-16">
        <div className="h-10 w-10 animate-spin rounded-full border-4 border-[var(--color-primary)] border-t-transparent" />
      </div>
    );
  }

  if (forbidden) {
    return (
      <div className="rounded-2xl bg-[var(--color-surface)] p-8 text-center shadow-sm">
        <p className="text-[var(--color-text-muted)]">{t("rooms.forbiddenRoom")}</p>
        <Link to="/rooms" className="mt-4 inline-block text-[var(--color-primary)]">
          {t("rooms.backToRooms")}
        </Link>
      </div>
    );
  }

  if (!room) {
    return (
      <div className="rounded-2xl bg-[var(--color-surface)] p-8 text-center shadow-sm">
        <p className="text-[var(--color-text-muted)]">{t("rooms.roomNotFound")}</p>
        <Link to="/rooms" className="mt-4 inline-block text-[var(--color-primary)]">
          {t("rooms.backToRooms")}
        </Link>
      </div>
    );
  }

  return (
    <PageShell
      breadcrumb={[
        { label: t("nav.home"), to: "/" },
        { label: t("rooms.title"), to: "/rooms" },
        { label: room.name },
      ]}
      title={room.name}
      titleAside={
        <div className="inline-flex items-center gap-2">
          <span
            className={`inline-flex rounded-md border px-2 py-0.5 text-xs font-semibold ${riwayaBadgeClass(room.riwaya)}`}
          >
            {t(`mushaf.${room.riwaya}`)}
          </span>
          <span
            className={`inline-flex rounded-md border px-2 py-0.5 text-xs font-semibold ${halaqahBadgeClass(room.halaqah_type)}`}
          >
            {t(`rooms.halaqah${capitalize(room.halaqah_type)}`)}
          </span>
        </div>
      }
      actions={
        showActions ? (
          <div className="flex flex-wrap gap-2">
            <Button type="button" variant="secondary" onClick={() => setFormOpen(true)}>
              <span className="inline-flex items-center gap-2">
                <Pencil className="h-4 w-4" />
                {t("common.edit")}
              </span>
            </Button>
            {isArchived ? (
              <Button type="button" variant="primary" loading={restoreLoading} onClick={() => void handleRestore()}>
                <span className="inline-flex items-center gap-2">
                  <RotateCcw className="h-4 w-4" />
                  {t("common.restore")}
                </span>
              </Button>
            ) : (
              <Button type="button" variant="secondary" onClick={() => setArchiveOpen(true)}>
                <span className="inline-flex items-center gap-2 text-amber-800">
                  <Archive className="h-4 w-4" />
                  {t("common.archive")}
                </span>
              </Button>
            )}
          </div>
        ) : undefined
      }
    >
      {isArchived ? (
        <div
          className="rounded-2xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-950"
          role="status"
        >
          {t("rooms.archivedRoomNotice")}
        </div>
      ) : null}

      {isRoomTeacher && !isArchived ? (
        <GettingStartedBanner
          roomId={room.id}
          hasStudents={enrolledCount > 0}
          hasSessions={(room?.sessions_count ?? 0) > 0 || sessions.length > 0}
          onAddStudent={() => setEnrollOpen(true)}
          onAddSession={() => {
            setSessionPrefillDate(null);
            setSessionPresetMorning(false);
            setSessionFormOpen(true);
          }}
        />
      ) : null}

      <div className="space-y-6">
        <RoomOverviewSection
          room={room}
          user={user}
          isArchived={isArchived}
          studentActionLoading={studentActionLoading}
          onStudentJoin={() => void handleStudentJoin()}
          onLeaveRoom={() => setStudentConfirm("leave")}
          onCancelPendingRequest={() => setStudentConfirm("cancel")}
        />

        {showStudentsSection ? (
          <RoomStudentsSection
            room={room}
            user={user}
            enrollments={enrollments}
            enrolledCount={enrolledCount}
            showActions={showActions}
            isArchived={isArchived}
            onRefresh={() => {
              // No-op: PendingRequestsList invalidates its own keys.
            }}
            onEnrollOpen={() => setEnrollOpen(true)}
            onRemoveEnrollment={(e) => setRemoveEnrollment(e)}
          />
        ) : null}

        <RoomSessionsSection
          room={room}
          user={user}
          roomRouteId={id}
          sessions={sessions}
          sessionsLoading={sessionsLoading}
          sessionsViewMode={sessionsViewMode}
          setSessionsViewMode={setSessionsViewMode}
          calendarCursor={calendarCursor}
          setCalendarCursor={setCalendarCursor}
          listMonthCursor={listMonthCursor}
          setListMonthCursor={setListMonthCursor}
          isArchived={isArchived}
          onSessionFormOpen={() => {
            setSessionPrefillDate(null);
            setSessionPresetMorning(false);
            setSessionFormOpen(true);
          }}
          onCalendarDayClick={(d) => {
            setSessionPrefillDate(d);
            setSessionPresetMorning(true);
            setSessionFormOpen(true);
          }}
        />

        {showRecitationsSection ? (
          <RoomRecitationsSection
            room={room}
            user={user}
            roomRecitations={roomRecitations}
            recitationsLoading={recitationsLoading}
            isArchived={isArchived}
            onRecitationFormOpen={() => setRecitationFormOpen(true)}
          />
        ) : null}
      </div>

      <SessionFormModal
        open={sessionFormOpen}
        mode="create"
        session={null}
        defaultRoomId={room.id}
        defaultDatetime={sessionPrefillDate}
        presetMorningStart={sessionPresetMorning}
        onClose={() => {
          setSessionFormOpen(false);
          setSessionPrefillDate(null);
          setSessionPresetMorning(false);
        }}
        onSaved={() => {
          void invalidateRoomSessions();
          void queryClient.invalidateQueries({ queryKey: roomKeys.detail(room.id) });
        }}
      />

      <RecitationFormModal
        open={recitationFormOpen}
        mode="create"
        recitation={null}
        defaultRoomId={room.id}
        defaultRoomName={room.name}
        onClose={() => setRecitationFormOpen(false)}
        onSaved={() => {
          void invalidateRoomRecitations();
        }}
      />

      <RoomFormModal
        open={formOpen}
        mode="edit"
        room={room}
        isAdmin={isAdmin}
        onClose={() => setFormOpen(false)}
        onSaved={() => {
          // No-op: RoomFormModal invalidates room keys itself.
        }}
      />

      <ArchiveRoomModal
        open={archiveOpen}
        roomId={room.id}
        roomName={room.name}
        onClose={() => setArchiveOpen(false)}
        onArchived={() => navigate("/rooms", { replace: true })}
      />

      <EnrollStudentModal
        open={enrollOpen}
        roomId={room.id}
        maxStudents={room.max_students}
        currentCount={enrolledCount}
        onClose={() => setEnrollOpen(false)}
        onEnrolled={() => {
          // No-op: EnrollStudentModal invalidates enrollment keys itself.
        }}
      />

      <RemoveStudentModal
        open={removeEnrollment !== null}
        roomId={room.id}
        enrollment={removeEnrollment}
        onClose={() => setRemoveEnrollment(null)}
        onRemoved={() => {
          // No-op: RemoveStudentModal invalidates enrollment keys itself.
        }}
      />

      <AlertDialog
        open={studentConfirm !== null}
        onOpenChange={(open) => {
          if (!open) setStudentConfirm(null);
        }}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              {studentConfirm === "leave"
                ? t("enrollment.leaveRoom")
                : t("enrollment.cancelRequest")}
            </AlertDialogTitle>
            <AlertDialogDescription>
              {studentConfirm === "leave"
                ? t("enrollment.leaveConfirm")
                : t("enrollment.cancelRequestConfirm")}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => setStudentConfirm(null)}
              disabled={studentActionLoading}
            >
              {t("common.cancel")}
            </Button>
            <Button
              type="button"
              variant="danger"
              loading={studentActionLoading}
              onClick={() => void confirmStudentWithdrawal()}
            >
              {t("common.confirm")}
            </Button>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </PageShell>
  );
}
